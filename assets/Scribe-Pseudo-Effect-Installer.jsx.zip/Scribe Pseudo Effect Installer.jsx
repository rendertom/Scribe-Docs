// alert(File.decode("%3CEffect%20matchname%3D%22Pseudo%2F9db0uID%2FScribe%22%20name"))

var myComp = app.project.activeItem;
var myLayer = myComp.selectedLayers[0];
var par = myLayer.property('Effects').addProperty('Pseudo/9db0uID/Scribe'); // parallel

var all =
  '%3CEffect%20matchname%3D%22Pseudo%2F9db0uID%2FScribe%22%20name%3D%22%24%24%24%2FAE%2FPreset%2FScribe%3DScribe%22%3E%0A%3CColor%20name%3D%22%24%24%24%2FAE%2FPreset%2FColor%3DColor%22%20default_red%3D%22255%22%20default_green%3D%22255%22%20default_blue%3D%22255%22%20%2F%3E%0A%3CSlider%20name%3D%22%24%24%24%2FAE%2FPreset%2FThickness%3DThickness%22%20default%3D%220%22%20valid_min%3D%220%22%20valid_max%3D%221000%22%20slider_min%3D%220%22%20slider_max%3D%22100%22%20precision%3D%221%22%2F%3E%0A%20%20%20%20%3CGroup%20name%3D%22%24%24%24%2FAE%2FPreset%2FTrim%3DTrim%22%3E%0A%20%20%20%20%3CSlider%20name%3D%22%24%24%24%2FAE%2FPreset%2FStart%3DStart%22%20default%3D%220%22%20valid_min%3D%22-0%22%20valid_max%3D%22100%22%20slider_min%3D%220%22%20slider_max%3D%22100%22%20precision%3D%221%22%2F%3E%0A%20%20%20%20%3CSlider%20name%3D%22%24%24%24%2FAE%2FPreset%2FEnd%3DEnd%22%20default%3D%22100%22%20valid_min%3D%220%22%20valid_max%3D%22100%22%20slider_min%3D%220%22%20slider_max%3D%22100%22%20precision%3D%221%22%2F%3E%0A%20%20%20%20%3CSlider%20name%3D%22%24%24%24%2FAE%2FPreset%2FOffset%3DOffset%22%20default%3D%220%22%20valid_min%3D%22-1000%22%20valid_max%3D%221000%22%20slider_min%3D%22-100%22%20slider_max%3D%22100%22%20precision%3D%221%22%2F%3E%0A%3C%2FGroup%3E%0A%3C%2FEffect%3E';
var instName = 'Scribe';
function PseudoEffectInstaller() {
  var clearInstName, startInst, endInst, myPalette, inst, deinst;

  clearInstName = decodeURIComponent(instName);
  startInst = encodeURIComponent('<!-- ') + instName + encodeURIComponent('_start -->');
  endInst = encodeURIComponent('<!-- ') + instName + encodeURIComponent('_end -->');

  function isNetworkAccessAllowed() {
    var securitySetting;

    securitySetting = app.preferences.getPrefAsLong(
      'Main Pref Section',
      'Pref_SCRIPTING_FILE_NETWORK_SECURITY'
    );
    if (!securitySetting)
      alert(
        'Please set preference "Allow Scripts to Write Files and Access Network". \n \nWindows:   After Effects  > Edit > Preferences > General \n \nMac:   After Effects > Preferences > General   '
      );
    return securitySetting;
  }

  function checkOS() {
    var appFolderPath, cmd;

    if ($.os.indexOf('Windows') > -1) {
      //if Windows
      appFolderPath = new Folder(Folder.appPackage).fsName.toString();
      cmd = 'cmd /c attrib -r /S /D ' + '"' + appFolderPath + '"';
      system.callSystem(cmd);
      cmd = 'cmd /c attrib -r /S /D ' + '"' + appFolderPath + '\\' + 'PresetEffects.xml"';
      appFolderPath = appFolderPath + '\\';
      system.callSystem(cmd);
    } else {
      //if Mac
      appFolderPath =
        new Folder(Folder.appPackage.absoluteURI).fsName.toString() + '/Contents/Resources/';
      cmd = 'chmod u+rw  ' + '"' + appFolderPath + 'PresetEffects.xml"';
      system.callSystem(cmd);
    }

    return appFolderPath;
  }

  // Install Click
  function on_inst_click() {
    var alreadyInst, AEPath, tempFile, XMLFile, XMLFileIsOK, tempFileIsOK, curLine;

    alreadyInst = 0;

    if (!isNetworkAccessAllowed()) return '';

    AEPath = checkOS();

    tempFile = new File(AEPath + 'temp.xml');
    XMLFile = new File(AEPath + 'PresetEffects.xml');

    XMLFileIsOK = XMLFile.open('r', 'TEXT', '????');
    tempFileIsOK = tempFile.open('w', 'TEXT', '????');

    if (!XMLFileIsOK) {
      alert("Installation Error: Can't read PresetEffects.xml ");
      return '';
    }

    while (!XMLFile.eof) {
      curLine = XMLFile.readln();
      if (curLine == decodeURIComponent(startInst)) alreadyInst = 1;
      if (curLine.indexOf('</Effects>') == -1) tempFile.writeln(curLine);
      else break;
    }

    tempFile.writeln(
      decodeURIComponent(startInst + '%0A' + all + '%0A' + endInst + '%0A%3C%2FEffects%3E')
    );

    if (alreadyInst == 1) {
      alert(clearInstName + ' already installed !');
      XMLFile.close();
      tempFile.close();
      tempFile.remove();
    } else {
      XMLFile.close();
      tempFile.close();
      XMLFile.remove();
      tempFile.rename('PresetEffects.xml');
      alert('Installation complete\nPlease restart After Effects');
    }
  }

  // Deinstall Click
  function on_deinst_click() {
    var appFolderPath, AEPath, tempFile, tempFileIsOK, XMLFile, XMLFileIsOK, writeOk, curLine;

    if ($.os.indexOf('Windows') > -1) {
      appFolderPath = new Folder(Folder.appPackage).fsName.toString() + '\\';
    } else {
      appFolderPath =
        new Folder(Folder.appPackage.absoluteURI).fsName.toString() + '/Contents/Resources/';
    }

    AEPath = appFolderPath;

    tempFile = new File(AEPath + 'temp.xml');
    tempFileIsOK = tempFile.open('w', 'TEXT', '????');

    XMLFile = new File(AEPath + 'PresetEffects.xml');
    XMLFileIsOK = XMLFile.open('r', 'TEXT', '????');
    writeOk = 1;

    if (XMLFileIsOK && tempFileIsOK) {
      while (!XMLFile.eof) {
        curLine = XMLFile.readln();
        if (curLine.indexOf(decodeURIComponent(startInst)) != -1) writeOk = 0;

        if (curLine.indexOf(decodeURIComponent(endInst)) != -1) {
          writeOk = 1;
          continue;
        }

        if (writeOk == 1) tempFile.writeln(curLine);
      }
    }

    if (tempFile.length != XMLFile.length && tempFile.length > 0) {
      XMLFile.close();
      tempFile.close();
      XMLFile.remove();
      tempFile.rename('PresetEffects.xml');
      alert('Removing ' + clearInstName + ' complete');
    } else {
      XMLFile.close();
      tempFile.close();
      tempFile.remove();
      alert('Nothing to remove');
    }
  }

  myPalette = new Window('palette', clearInstName + ' Installer', [400, 300, 695, 410]);

  inst = myPalette.add('button', [10, 10, 285, 50], 'Install ' + clearInstName);
  inst.onClick = on_inst_click;

  deinst = myPalette.add('button', [10, 60, 285, 100], 'Remove ' + clearInstName);
  deinst.onClick = on_deinst_click;

  myPalette.center();
  myPalette.show();
}
PseudoEffectInstaller();
